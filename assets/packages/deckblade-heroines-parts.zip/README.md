# 14 位女性角色 · 战斗骨架分件
新增蕾刃、红心、浪花、炎舞、翠凰、雷音。每人九格，按随包 parts/parts.json 的格位和挂点使用；native 为 104×124 原生图，x8 为 832×992。前八位仍为第一轮返工后的资产。所有角色的 check/ 均为上游组装器的输出；GIF 使用有留白的画布，不代表游戏技能时序。赤鬃与夜蔷本轮只返工站姿，未收入这个分件包。
复验：python -I tools/assemble.py native/seafoam.png parts/parts.json parts/poses.json rebuilt.png

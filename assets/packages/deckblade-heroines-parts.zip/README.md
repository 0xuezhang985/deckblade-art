# 牌刃疾行 · 八位女性角色战斗骨架分件
版本来源：qq63396306/deckblade-art，提交 6d7deadef06b782b6b85cac259e0307a742d807a，HEROINE PARTS。角色参考为资产 fork 提交 2cab1eb 的八张定稿站姿。本包不替换站姿，不包含游戏逻辑或解锁配置。
- native/ 与 x8/ 各 8 张透明 PNG，一人一张。游戏使用 104×124 原生图集，832×992 是逐像素最近邻放大。按 parts/parts.json 的 rect、pivot、end 读取，不要裁去格内留白。
- 每人九件：头、躯干、上臂、前臂含握拳、大腿、小腿、鞋、颈后挂件、武器。长发及背后衣物在 cape 格，裙摆或袍片随相应腿部转动。远侧四肢由骨架复用并压暗。
- sword 格按角色替换为环杖、晶枪、直刃、短弯刀、铃杖、短魔杖、手枪、旗枪。月影仅一把刀、焰铳仅一把枪，天穹不带单侧盾牌，绯刃左右共用相同护腕。它们不是第二套站姿。
- check/ 为上游未修改的组装器输出。原工具采用固定画布，预览图的边界有时会切到剑尖或脚；pose-check.gif 使用相同绘制函数和统一的较大画布，展示完整动作。动画速度仅供验收。
- 固定姿势：站立 1、跑步 4、连击 6、拳击 4、升龙 4。八人共 152 个角色姿势；原生图和八倍图组装结果逐像素相同。已离线验证，尚未在游戏客户端实装。

## 解压复现（Python + Pillow）
    python -I tools/assemble.py native/starweave.png parts/parts.json parts/poses.json starweave-check.png
将 starweave 换成 manifest.json 中任何角色 ID 均可。
